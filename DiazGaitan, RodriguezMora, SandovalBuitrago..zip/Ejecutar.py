from Generador import ondas
from Generador import cuadrada
from Generador import triangular
from Generador import sierra
from Archivar import file

def main():

    print ("Generador de Ondas")

    opcion = input("Escoja una opcion: \n1.Sinosoidal \n2.Cuadrada \n3.Triangular \n4.Diente de Sierra \n ")
    print ("Ingrese los datos: ")
    Tone = input("Digite la frecuencia del tono a generar: ")
    Time = input("Ingrese el tiempo de audio en segundos: ")
    Frecuenciademuestreo = input("Ingrese la frecuencia de muestreo: ")
    Pbits = input("Ingrese el numero de bits: ")
    Name = raw_input("Ingrese el nombre del archivo a generar: ")
    Name = (Name+".wav")

    if opcion == 1:

        senal = ondas(Tone, Frecuenciademuestreo, Pbits, Time)
        onda = senal.sinusoidal()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)

    if opcion == 2:

        senal = cuadrada(Tone, Frecuenciademuestreo, Pbits, Time)
        onda = senal.square()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)

    if opcion == 3:

        senal = triangular(Tone, Frecuenciademuestreo, Pbits, Time)
        onda = senal.triangulo()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)

    if opcion == 4:

        senal = sierra(Tone, Frecuenciademuestreo, Pbits, Time)
        onda = senal.diente()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)



if __name__== "__main__":
    main()