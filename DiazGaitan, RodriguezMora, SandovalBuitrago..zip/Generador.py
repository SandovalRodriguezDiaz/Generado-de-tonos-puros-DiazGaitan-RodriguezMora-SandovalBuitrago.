import math
import matplotlib.pylab as plt

class ondas:
    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.size = fmuestreo * time

    def sinusoidal(self):

        for i in range(0, self.size):

            valores = ((2**self.Profundidadb)/2)*math.sin((2*math.pi*self.Frecuencia*i)/self.Frecuenciam)
            ondas.wavearray.append(valores)

        return ondas.wavearray

    def graficar(self, array):
        plt.plot(array, color="green", linewidth=1.0, linestyle="-")
        plt.show()

class cuadrada:

    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.size = fmuestreo * time
    def square(self):

        for i in range(0, self.size):



            for j in range(1, 100):

                sumatoria = ((4/(j*math.pi))*math.sin(2*math.pi*j*self.Frecuenciam*self.Duracion))
                cuadrada.wavearray.append(sumatoria)

        return cuadrada.wavearray



    def graficar(self, array):
        plt.plot(array, color="red", linewidth=1.0, linestyle="-")
        plt.show()


class triangular:

    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.size = fmuestreo * time

    def triangulo(self):

        for i in range(0, self.size):



            for j in range(1, 100):

                sumatoria = (8/math.pi**2)*(((-1**(50-1)/2)/j**2)*math.sin(2*math.pi*self.Frecuencia*j*self.Duracion))
                triangular.wavearray.append(sumatoria)

        return triangular.wavearray



    def graficar(self, array):
        plt.plot(array, color="yellow", linewidth=1.0, linestyle="-")
        plt.show()

class sierra:

    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.size = fmuestreo * time

    def diente(self):

        for i in range(0, self.size):



            for j in range(1, 100):

                sumatoria = (-2/math.pi)*((1/j)*math.sin(2*math.pi*self.Frecuenciam*j*self.Duracion))
                sierra.wavearray.append(sumatoria)

        return sierra.wavearray



    def graficar(self, array):
        plt.plot(array, color="purple", linewidth=1.0, linestyle="-")
        plt.show()